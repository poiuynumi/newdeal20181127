var control = "";

var listpath;
var viewpath;
var writepath;
var replypath;
var modifypath;
var deletepath;

function initVars() {
	listpath = control + "/list.bit";
	viewpath = control + "/view.bit";
	writepath = control + "/write.bit";
	replypath = control + "/reply.bit";
	modifypath = control + "/modify.bit";
	deletepath = control + "/delete.bit";
}
