package com.bit.board.service;

public interface MemoService {

}
