package com.bit.board.dao;

public interface AlbumDao {

}
