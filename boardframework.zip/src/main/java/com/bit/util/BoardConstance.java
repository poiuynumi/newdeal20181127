package com.bit.util;

public class BoardConstance {

	public final static int LIST_COUNT = 20;
	public final static int PAGE_COUNT = 10;
	
}
