package com.bit.common.service;

public interface CommonService {

}
