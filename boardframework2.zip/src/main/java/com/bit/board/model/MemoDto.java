package com.bit.board.model;

public class MemoDto {

}
