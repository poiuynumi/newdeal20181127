package com.bit.board.common.service;

public interface CommonService {

}
